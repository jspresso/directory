// Implement your domain here using the SJS DSL.
